export { default } from '@hypernym/prettier-config/svelte'
