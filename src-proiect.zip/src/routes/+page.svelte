<script lang="ts">
  import { Head } from '$/components/head'
</script>

<Head />

<div>
  <h1>Home page</h1>
</div>
