<script lang="ts">
  import { Head } from '$/components/head'
</script>

<Head title="About page" />

<div>
  <h1>About page</h1>
</div>
