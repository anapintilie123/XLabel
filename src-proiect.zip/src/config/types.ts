export interface ConfigApp {
  name: string
  author: string
  description: string
  url: string
}
