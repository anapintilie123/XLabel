import type { ConfigApp } from './types'

export const app: ConfigApp = {
  name: 'SvelteKit Boilerplate',
  author: '',
  description: 'SvelteKit starter template.',
  url: '',
}
