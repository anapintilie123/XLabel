// Global types only
