export interface HeadMeta {
  title?: string
  titleTemplate?: (title: string, description: string) => string
  description?: string
}
