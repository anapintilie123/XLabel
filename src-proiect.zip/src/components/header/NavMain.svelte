<script lang="ts">
	import { base } from '$app/paths';
</script>

<nav id="nav-main" class="flex space-x-3 font-600">
  <a href="{base}/">Home</a>
  <a href="{base}/about">About</a>
</nav>
