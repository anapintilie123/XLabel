<script lang="ts">
  import NavMain from './NavMain.svelte'
</script>

<header class="flex">
  <NavMain />
</header>
